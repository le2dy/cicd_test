package doomchit;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageSeat extends Base {
    JButton seatBtn[] = new JButton[120];
    JPanel teen = new JPanel(null);

    public ManageSeat() {
        super("좌석관리", 700, 800);
        setLayout(null);

        addComp(new JLabel("1층"), 0, 0, 100, 25);
        addComp(new JLabel("2층"), 0, 400, 100, 25);
        teen.setBorder(new LineBorder(Color.BLACK));
        addComp(teen, 0, 220, 530, 130);

        loadSeats();

        setVisible(true);
    }

    void loadSeats() {

        try {
            ResultSet rs = stmt.executeQuery("select * from seat");
            int idx = 0;
            int i = 0;
            int j = 0;
            while (rs.next()) {
                idx = rs.getInt(1);
                seatBtn[idx] = new JButton(idx + "");
//                seatBtn[idx].setFocusPainted(false);

                if (rs.getInt("s_unused") == 1) {
                    seatBtn[idx].setBackground(Color.LIGHT_GRAY);
                    seatBtn[idx].setName("unused");
                }
                if (rs.getInt("s_used") == 1) {
                    seatBtn[idx].setBackground(Color.ORANGE);
                    seatBtn[idx].setName("used");
                }
                if (rs.getInt("s_break") == 1) {
                    seatBtn[idx].setBackground(Color.YELLOW);
                    seatBtn[idx].setName("break");
                }
                if (rs.getInt("s_cleaning") == 1) {
                    seatBtn[idx].setBackground(Color.RED);
                    seatBtn[idx].setName("cleaning");
                }

                if ((idx >= 1 && idx <= 36)) {
                    addComp(seatBtn[idx], 5 + (i % 9 * 75), 35 + (i / 9 * 35) + (i / 18 * 20), 70, 30);
                    i++;
                } else if ((idx >= 58 && idx < 120)) {
                    addComp(seatBtn[idx], 5 + (i % 9 * 75), 250 + (i / 9 * 35) + (i / 18 * 20), 70, 30);
                    i++;
                } else {
                    addComp(teen, seatBtn[idx], 5 + (j % 7 * 75), 5 + (j / 7 * 35) + (j / 14 * 20), 70, 30);
                    j++;
                }

                seatBtn[idx].setBorder(new LineBorder(Color.BLACK));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int i = 1; i < seatBtn.length - 1; i++) {
            final int j = i;
            seatBtn[i].addActionListener(a -> {
                JButton btn = (JButton) a.getSource();
                Color col;
                String sql = "";
                String state = "";

                if(btn.getName().equals("unused")) {
                    col = Color.RED;
                    sql = "S_used = 0, S_unused = 0, S_break = 0, S_cleaning = 1";
                    state = "cleaning";
                } else if(btn.getName().equals("cleaning")) {
                    col = Color.YELLOW;
                    sql = "S_used = 0, S_unused = 0, S_break = 1, S_cleaning = 0";
                    state = "break";
                } else if(btn.getName().equals("break")) {
                    col = Color.LIGHT_GRAY;
                    sql = "S_used = 0, S_unused = 1, S_break = 0, S_cleaning = 0";
                    state = "unused";
                } else {
                    errmsg("사용 중인 좌석은 좌석 상태를 변경할 수 없습니다.");
                    return;
                }

                btn.setBackground(col);
                btn.setName(state);
                execute("update seat set " + sql + " where s_no = " + j);
            });
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setStroke(new BasicStroke(3));
        g2.drawLine(0, 400, 700, 400);

        Color[] col = {Color.LIGHT_GRAY, Color.YELLOW, Color.ORANGE, Color.RED};
        String[] str = "미사용,고장,사용중,청소중".split(",");

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setStroke(new BasicStroke(1));
        for (int i = 0; i < col.length; i++) {
            g2.setColor(col[i]);
            g2.fillRect(400 + (i * 75), 40, 10, 10);
            g2.setColor(Color.BLACK);
            g2.drawRect(400 + (i * 75), 40, 10, 10);
            g2.drawString(str[i], 420 + (i * 75), 50);
        }
    }

    public static void main(String[] args) {
        new ManageSeat();
    }
}

package doomchit;

public class purchaseCodeCheck {
    public purchaseCodeCheck(int sel) {
    }
}

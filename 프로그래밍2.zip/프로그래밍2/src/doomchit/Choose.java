package doomchit;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.TimerTask;

public class Choose extends Base {
    JPanel north = new JPanel(new BorderLayout());
    JPanel nc = new JPanel(new GridLayout(0, 2));
    JPanel east = new JPanel(new GridLayout(0, 1, 0, 10));
    JPanel c;
    JLabel id = new JLabel();
    JLabel leftTime = new JLabel();
    JLabel leftMoney = new JLabel();
    JPanel teen = new JPanel(null);
    JButton menuBtns[] = {
            new JButton("자리선택"),
            new JButton("시간/금액"),
            new JButton("쿠폰보기"),
            new JButton("출석체크"),
            new JButton("매접이용"),
            new JButton("퇴실하기"),
    };
    JButton autoSelect = new JButton("자동 선택");
    JButton[] seatBtn = new JButton[120];
    int age = -1;
    String state = "선택";

    public Choose() {
        super("자리선택", 800, 800);
        setLayout(new BorderLayout());

        c = new JPanel(null) {
            @Override
            public void paint(Graphics g) {
                super.paint(g);

                Graphics2D g2 = (Graphics2D) g;

                Color[] col = {Color.LIGHT_GRAY, Color.YELLOW, Color.ORANGE, Color.RED};
                String[] str = "미사용,고장,사용중,청소중".split(",");

                for (int i = 0; i < col.length; i++) {
                    g2.setColor(col[i]);
                    g2.fillRect(250 + (i * 80), 10, 10, 10);
                    g2.setColor(Color.BLACK);
                    g2.drawRect(250 + (i * 80), 10, 10, 10);
                    g2.drawString(str[i], 270 + (i * 80), 20);
                }

                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.BLUE);
                g2.setFont(new Font("", Font.BOLD, 13));
                g2.drawString("미성년자", 0, 218);
            }
        };

        add(north, "North");
        add(east, "West");
        add(c);

        north.add(new JLabel("기능 PC방"), "West");
        north.add(nc);

        nc.add(id);
        nc.add(leftTime);
        nc.add(new JLabel(""));
        nc.add(leftMoney);

        for (int i = 0; i < menuBtns.length; i++) {
            east.add(menuBtns[i]);
            if (i > 2) menuBtns[i].setEnabled(false);
            menuBtns[i].addActionListener(a -> {
                if(a.getSource().equals(menuBtns[0])) {
                    if(menuBtns[0].getText().equals("자리선택")) {
                        state = "선택";
                    } else {
                        state = "이동";
                    }
                }
            });
        }
        menuBtns[0].setForeground(Color.RED);

        addComp(c, new JLabel("1층"), 0, 0, 100, 30);
        addComp(c, new JLabel("2층"), 0, 400, 100, 30);
        addComp(c, autoSelect, 615, 0, 100, 30);
        addComp(c, teen, 0, 220, 550, 180);

        setUser();
        loadSeats();

        autoSelect.addActionListener(a -> {
            Random randyrandom = new Random();
            int sel = randyrandom.nextInt(118) + 1;
            if (!seatBtn[sel].isEnabled()) sel = randyrandom.nextInt(118) + 1;
            seatBtn[sel].doClick();
        });

        teen.setBorder(new LineBorder(Color.BLACK));
        c.setBorder(new LineBorder(Color.BLACK));

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    void loadSeats() {

        try {
            ResultSet rs = stmt.executeQuery("select * from seat");
            int idx = 0;
            int i = 0;
            int j = 0;
            while (rs.next()) {
                idx = rs.getInt(1);
                seatBtn[idx] = new JButton(idx + "");

                if (rs.getInt("s_unused") == 1) seatBtn[idx].setBackground(Color.LIGHT_GRAY);
                if (rs.getInt("s_used") == 1) seatBtn[idx].setBackground(Color.ORANGE);
                if (rs.getInt("s_break") == 1) seatBtn[idx].setBackground(Color.YELLOW);
                if (rs.getInt("s_cleaning") == 1) seatBtn[idx].setBackground(Color.RED);

                if (rs.getInt("s_used") == 1 || rs.getInt("s_break") == 1 || rs.getInt("s_cleaning") == 1) {
                    seatBtn[idx].setEnabled(false);
                }


                if ((idx >= 1 && idx <= 36)) {
                    addComp(c, seatBtn[idx], 5 + (i % 9 * 75), 35 + (i / 9 * 35) + (i / 18 * 20), 70, 30);
                    if (age < 19) seatBtn[idx].setEnabled(false);
                    seatBtn[idx].setName(1 + "/" + idx);
                    i++;
                } else if ((idx >= 58 && idx < 120)) {
                    addComp(c, seatBtn[idx], 5 + (i % 9 * 75), 250 + (i / 9 * 35) + (i / 18 * 20), 70, 30);
                    if (age < 19) seatBtn[idx].setEnabled(false);
                    seatBtn[idx].setName(2 + "/" + idx);
                    i++;
                } else {
                    addComp(teen, seatBtn[idx], 5 + (j % 7 * 75), 5 + (j / 7 * 35) + (j / 14 * 20), 70, 30);
                    if (age >= 19) seatBtn[idx].setEnabled(false);
                    seatBtn[idx].setName(1 + "/" + idx);
                    j++;
                }

                seatBtn[idx].setBorder(new LineBorder(Color.BLACK));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int i = 1; i < seatBtn.length - 1; i++) {
            seatBtn[i].addActionListener(a -> {
                if (TIME < 1800) {
                    errmsg("시간을 충전한 후 이용해주세요.");
                } else {
                    JButton btn = ((JButton) a.getSource());

                    if (state.equals("선택")) {
                        String[] sname = btn.getName().split("/");
                        msg("회원님의 자리는 " + sname[0] + "층 " + sname[1] + "번입니다.");
                        menuBtns[0].setText("자리 이동");
                        for (int j = 1; j < menuBtns.length; j++) {
                            if (NO == -1 && (j == 2 || j == 3)) continue;
                            menuBtns[j].setEnabled(true);
                        }

                        execute("update seat set s_used = 1, s_unused = 0 where s_no = " + toInt(btn.getName().split("/")[1]));

                        TimerTask task = new TimerTask() {
                            @Override
                            public void run() {
                                if (TIME == 0) timer.cancel();
                                int t = CHARGE_TIME - TIME;
                                int h = t / 3600;
                                int m = t % 3600 / 60;
                                int s = t % 60;

                                execute("update time set t_used = '" + (h + ":" + m + ":" + s) + "' where m_no = " + NO);
                                t = TIME;
                                h = t / 3600;
                                m = t % 3600 / 60;
                                s = t % 60;
                                leftTime.setText("남은 시간: " + format.format(h) + ":" + format.format(m) + ":" + format.format(s));
                                TIME--;
                            }
                        };

                        timer.schedule(task, 0, 1000);
                    } else {
                        int move = toInt(btn.getName().split("/")[1]);
                        if(CURRENT_SEAT == move) {
                            errmsg("현재 사용중인 좌석입니다.");
                            return;
                        }

                        String[] sname = btn.getName().split("/");
                        msg(sname[0] + "층 " + sname[1] + "번으로 자리를 이동입니다.");

                        execute("update seat set s_used = 0, s_unused = 1 where s_no = " + CURRENT_SEAT);
                        execute("update seat set s_used = 1, s_unused = 0 where s_no = " + move);
                        CURRENT_SEAT = move;
                    }

                    CURRENT_SEAT = toInt(btn.getName().split("/")[1]);
                }
            });
        }
    }

    void setUser() {
        if (NO == -1) {
            id.setText("비회원");
            leftTime.setText("남은 시간: 00:00:00");
            leftMoney.setText("남은 금액: 0");
            return;
        }

        try {
            ResultSet rs = stmt.executeQuery("select * from member where m_no = " + NO);
            if (rs.next()) {
                id.setText("회원 아이디: " + rs.getString("m_id"));
                LocalDate now = LocalDate.now();
                LocalDate parsedBirthDate = LocalDate.parse(rs.getString("m_birth").replace("-", ""), DateTimeFormatter.ofPattern("yyyyMMdd"));

                age = now.minusYears(parsedBirthDate.getYear()).getYear();

                if (parsedBirthDate.plusYears(age).isAfter(now)) {
                    age = age - 1;
                }
            }
            rs.close();

            rs = stmt.executeQuery("select * from payment where m_no = " + NO);
            int mon = 0;
            while (rs.next()) {
                mon += rs.getInt("p_price");
            }
            rs.close();

            rs = stmt.executeQuery("select * from used where m_no = " + NO);
            if (rs.next()) {
                mon -= rs.getInt("us_price");
            }

            CHANGE = mon;
            System.out.println(mon);
            rs = stmt.executeQuery("select * from time where m_no = " + NO);
            if (rs.next()) {
                String[] charge = rs.getString("t_charge").split(":");
                String[] used = rs.getString("t_used").split(":");

                int c = (toInt(charge[0]) * 3600) + (toInt(charge[1]) * 60) + toInt(charge[2]);
                int u = (toInt(used[0]) * 3600) + (toInt(used[1]) * 60) + toInt(used[2]);
                CHARGE_TIME = c;
                TIME = c - u;
            }
            int h = TIME / 3600;
            int m = TIME % 3600 / 60;
            int s = TIME % 60;

            leftTime.setText("남은 시간: " + String.format("%02d", h) + ":" + String.format("%02d", m) + ":" + String.format("%02d", s));
            leftMoney.setText("남은 금액: " + format.format(mon));
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        NO = 1;
        new Choose();
    }
}

package doomchit;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class test extends Base {
    ArrayList<Integer> testTop = new ArrayList<>();
    JButton c;

    public test() {
        super("실험", 500, 500);
        setLayout(new BorderLayout());

        add(new JButton("N"), "North");
        add(c = new JButton("C"), "Center");
        add(new JButton("S"), "South");
        add(new JButton("E"), "East");
        add(new JButton("W"), "West");

        testTop.add(0);
        testTop.add(1);
        testTop.add(2);

        c.addActionListener(a -> {
            testTop.add(0, 123);
            if(testTop.size() > 3) {
                testTop.remove(3);
            }
            System.out.println(testTop);
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new test();
    }
}

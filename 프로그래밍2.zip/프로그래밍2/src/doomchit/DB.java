package doomchit;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.*;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

public class DB {
    static Connection con;
    static Statement stmt;
    static {
        try {
            File f =  new File("/home/leedongyun/Desktop/프로그래밍2/qwe.sqlite");

            if(f.exists()) {
                if(f.delete()) {
                    System.out.println(f.getName() + " deleted.");
                } else {
                    System.out.println(f.getName() + " are still there.");
                }
            }

            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:/home/leedongyun/Desktop/프로그래밍2/qwe.sqlite";

            con = DriverManager.getConnection(url);

            stmt = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void execute(String sql) {
        try {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void createTable(String n, String c) {
        execute("create table "+n+"("+c+")");
        int i = 0;
        try(Scanner scanner = new Scanner(Paths.get("src/doomchit/datafiles/"+ n +".txt"))) {
            while (scanner.hasNextLine()) {
                i++;
                String line = scanner.nextLine();

                if(i == 1) continue;

                String[] data = line.split("\t");
                for(int j = 0; j < data.length; j++) {
                    data[j] = "'" + data[j] + "'";
                }
                String indata = Arrays.toString(data).replace("[","(").replace("]",")");

                execute("insert into "+n+" values "+indata);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DB() {
        createTable("Member", "m_no INTEGER PRIMARY KEY AUTOINCREMENT, m_id varchar(20), m_pw varchar(20), m_name varchar(10), m_birth date, m_sex int, m_grade varchar(2)");
        createTable("Time", "t_no INTEGER PRIMARY KEY AUTOINCREMENT, m_no int, t_charge time, t_used time, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Used", "us_no INTEGER PRIMARY KEY AUTOINCREMENT,m_no int, us_price int, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Timehis", "th_no INTEGER PRIMARY KEY AUTOINCREMENT, m_no int, th_date date, th_start time, th_end time, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Nonmember", "n_no INTEGER PRIMARY KEY AUTOINCREMENT, n_bank varchar(15), n_bnum varchar(20), n_pnum varchar(6), n_birth date");
        createTable("Payment", "p_no INTEGER PRIMARY KEY AUTOINCREMENT, m_no int, p_date date, p_price int, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Seat", "s_no INTEGER PRIMARY KEY, s_used int, s_unused int, s_break int, s_cleaning int");
        createTable("Coupon", "co_no INTEGER PRIMARY KEY AUTOINCREMENT, m_no int, store int, roulette int, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Attendance", "at_no integer primary key autoincrement, m_no int, at_date date, foreign key(m_no) references member(m_no) on delete cascade on update cascade");
        createTable("Category", "c_no integer primary key autoincrement, c_name varchar(10)");
        createTable("Product", "p_no INTEGER PRIMARY KEY AUTOINCREMENT, c_no int, pr_name varchar(20), pr_price int, pr_stock int, pr_total int, foreign key(c_no) references category(c_no) on delete cascade on update cascade");
        createTable("Bank", "b_no integer primary key autoincrement, m_no int, b_name varchar(15), b_num varchar(20), p_num varchar(6), foreign key(m_no) references member(m_no) on delete cascade on update cascade");

        Logger log = Logger.getLogger("logger");
        log.info("DB 생성 완료");
    }

    public static void main(String[] args) {
        new DB();
    }

}

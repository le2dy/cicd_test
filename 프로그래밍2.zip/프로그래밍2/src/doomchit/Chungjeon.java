package doomchit;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Chungjeon extends Base {
    JLabel[] priceLabel = new JLabel[10];
    JButton confirm = new JButton("확인");
    JButton cancel = new JButton("취소");
    JPanel c = new JPanel(new GridLayout(0, 2, 5, 5));
    JPanel south = new JPanel(new GridLayout(0, 1, 0, 5));
    int sel = -1;

    public Chungjeon() {
        super("금액충전", 200, 400);
        setLayout(new BorderLayout());

        add(new JLabel("금액 충전"), "North");
        add(c);
        add(south, "South");

        for (int i = 0; i < priceLabel.length; i++) {
            priceLabel[i] = new JLabel(format.format(i * 1000) + "원");
            priceLabel[i].setBorder(new LineBorder(Color.BLACK));
            priceLabel[i].setName((i * 1000) + "");
            c.add(priceLabel[i]);

            priceLabel[i].addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    for (int j = 0; j < priceLabel.length; j++) {
                        priceLabel[j].setBorder(new LineBorder(Color.BLACK));
                    }
                    JLabel label = (JLabel) e.getSource();
                    label.setBorder(new LineBorder(Color.RED));
                    sel = toInt(label.getName());
                }
            });
        }

        south.add(confirm);
        south.add(cancel);

        confirm.addActionListener( a -> {
            if(sel == -1) {
                errmsg("금액을 선택해주세요.");
                return;
            }

            new purchaseCodeCheck(sel);
        });

        cancel.addActionListener(a -> {
            dispose();
        });

        setVisible(true);
    }
}

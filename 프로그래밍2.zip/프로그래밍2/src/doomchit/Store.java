package doomchit;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Store extends Base {
    JTabbedPane tabbedPane = new JTabbedPane();
    JPanel all = new JPanel(new BorderLayout());
    JPanel noddles = new JPanel(new BorderLayout());
    JPanel drinks = new JPanel(new BorderLayout());
    JPanel snacks = new JPanel(new BorderLayout());
    JScrollPane allScr = new JScrollPane(all);
    JScrollPane noddleScr = new JScrollPane(noddles);
    JScrollPane drinkScr = new JScrollPane(drinks);
    JScrollPane snackScr = new JScrollPane(snacks);

    DefaultTableModel dtm = new DefaultTableModel(null, "이름,가격,수량".split(",")) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable table = new JTable(dtm);
    JScrollPane scr = new JScrollPane(table);
    JCheckBox useCoupon = new JCheckBox("매점 5,00원 쿠폰 사용하기");
    JLabel totalPrice = new JLabel("0원", JLabel.RIGHT);
    JButton orderButton = new JButton("주문하기");
    JPanel east = new JPanel(new BorderLayout());
    JPanel south = new JPanel(new BorderLayout());
    int category = 0;
    boolean hasCoupon = false;
    int tot = 0;

    public Store() {
        super("매점 이용", 800, 600);
        setLayout(new BorderLayout());

        add(tabbedPane);
        add(east, "East");

        east.add(scr);
        east.add(south, "South");

        south.add(useCoupon, "North");
        south.add(totalPrice);
        south.add(orderButton, "South");

        totalPrice.setPreferredSize(new Dimension(0, 100));
        totalPrice.setBorder(new LineBorder(Color.BLACK));

        tabbedPane.addTab("전체", allScr);
        tabbedPane.addTab("컵라면", noddleScr);
        tabbedPane.addTab("음료", drinkScr);
        tabbedPane.addTab("과자", snackScr);

        try {
            ResultSet rs = stmt.executeQuery("select * from coupon where m_no = " + NO);
            if(rs.next()) {
                if(rs.getInt("store") != 0) hasCoupon = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        loadMenus(1);

        useCoupon.setVisible(false);

        tabbedPane.addChangeListener(a -> {
            category = ((JTabbedPane) a.getSource()).getSelectedIndex();
            loadMenus(category);
        });

        useCoupon.addActionListener(a -> {
            if(useCoupon.isSelected()) {
                tot -= 5000;
            } else {
                tot += 5000;
            }

            totalPrice.setText(format.format(tot) + " 원");
        });

        orderButton.addActionListener(a -> {
            if(CHANGE < tot) {
                int yn = JOptionPane.showConfirmDialog(null, "금액이 부족합니다. 금액을 충전하시겠습니까?", "경고", JOptionPane.YES_NO_OPTION);

                if(yn == JOptionPane.YES_OPTION) {
                    new Chungjeon();
                } else {
                    tot = 0;
                    dtm.setRowCount(0);
                    totalPrice.setText(tot + " 원");
                }
            } else {
                int yn = JOptionPane.showConfirmDialog(null, "총 " + format.format(tot) + "원입니다. 주문하시겠습니까?", "안내", JOptionPane.YES_NO_OPTION);

                if(yn == JOptionPane.YES_OPTION) {
                    msg("주문이 완료되었습니다.");
                    CHANGE -= tot;
                    execute("insert into payment values(0," + NO + ",curdate(),'" + tot+ "')");
                    if(useCoupon.isSelected()) execute("update coupon set store = store - 1 where m_no = " + NO);
                } else {
                    tot = 0;
                    dtm.setRowCount(0);
                    totalPrice.setText(tot + " 원");
                }
            }
        });

        setVisible(true);
    }

    void loadMenus(int num) {
        JPanel[] tabs = {all, noddles, drinks, snacks};
        String cat = num == 0 ? "1=1" : "c_no = " + category;
        tabs[num].removeAll();
        JPanel temp = new JPanel(new GridLayout(0, 3, 10, 10));
        JPanel tempTop = new JPanel(null);
        tabs[num].add(tempTop, "North");
        tabs[num].add(temp);
        ArrayList<Integer> top3 = new ArrayList<>();
        ArrayList<String> top3Name = new ArrayList<>();
        top3.add(-1);
        top3Name.add("");

        try {
            ResultSet rs = stmt.executeQuery("select * from product where " + cat);
            while (rs.next()) {
                for (int i = 0; i < top3.size(); i++) {
                    if (!top3Name.contains(rs.getString("pr_name"))) {
                        if (rs.getInt("Pr_total") > top3.get(i)) {
                            top3.add(i, rs.getInt("Pr_total"));
                            top3Name.add(i, rs.getString("pr_name"));
                        }
                        if (top3.size() > 3) {
                            top3.remove(3);
                            top3Name.remove(3);
                        }
                    }
                }

                JLabel img = new JLabel("");
                img.setIcon(img(rs.getString("pr_name") + ".jpg", 100, 100));
                img.setName(rs.getString("pr_name"));
                img.setToolTipText(rs.getString("pr_name")+"("+ format.format(rs.getInt("pr_price"))+"원)");
                img.setBorder(new LineBorder(Color.BLACK));
                if (rs.getInt("pr_stock") == 0) img.setEnabled(false);

                img.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        boolean isExists = false;
                        if(!img.isEnabled()) return;
                        for (int i = 0; i < table.getRowCount(); i++) {
                            if(table.getValueAt(i, 0).equals(img.getName())) {
                                int cnt = toInt(table.getValueAt(i, 2)) + 1;
                                table.setValueAt(cnt, i, 2);
                                isExists = true;
                            }
                        }

                        if(!isExists ) {
                            Object[] row = {img.getName(), img.getToolTipText().split("\\(")[1].replace("원)",""), 1};
                            dtm.addRow(row);
                        }

//                        tot = 0;
                        int price, cnt;
                        if(tot == 0) {
                            for (int i = 0; i < table.getRowCount(); i++) {
                                price = toInt(table.getValueAt(i, 1).toString().replace(",",""));
                                cnt = toInt(table.getValueAt(i, 2).toString());
                                tot += price * cnt;
                            }
                        } else {
                            tot += toInt(img.getToolTipText().split("\\(")[1].replace(",","").replace("원)",""));
                        }

                        totalPrice.setText(format.format(tot) + " 원");
                        if(tot >= 5000 && hasCoupon) useCoupon.setVisible(true);
                    }
                });

                temp.add(img);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        tempTop.setPreferredSize(new Dimension(0, 100));
//340 = max  122 = max stock   bar width = 340 * ((x / max stock) * 100)
        for (int i = 0; i < top3.size(); i++) {
            JPanel btn = new JPanel(new BorderLayout());
            btn.add(new JLabel(top3Name.get(i)+"("+top3.get(i)+"개)"));
            btn.setBackground(Color.PINK);
            btn.setBorder(new LineBorder(Color.BLACK));
            addComp(tempTop, btn, 0, (i * 30), (int)(340 * ((double)top3.get(i) / (double)top3.get(0))), 25);
        }

        repaint();
        revalidate();
    }

    public static void main(String[] args) {
        NO = 1;
        CHANGE = 35000;
        new Store();
    }
}

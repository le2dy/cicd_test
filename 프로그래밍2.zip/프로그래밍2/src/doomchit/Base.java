package doomchit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Timer;

public class Base extends JFrame {
    static int NO = -1;
    static Connection con;
    static Statement stmt;
    DecimalFormat format = new DecimalFormat();
    static int TIME = -1;  //남은 시간
    static int CHARGE_TIME = -1;  //충전 시간
    static Timer timer = new Timer();
    static int CURRENT_SEAT = -1;
    static int CHANGE = -1;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
//            String url = "jdbc:sqlite:C:\\Users\\82103\\Desktop\\프로그래밍2\\qwe.sqlite";
            String url = "jdbc:sqlite:/home/leedongyun/Desktop/프로그래밍2/qwe.sqlite";

            con = DriverManager.getConnection(url);

            stmt = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    int toInt(Object obj) {
        return Integer.parseInt(obj.toString());
    }

    ImageIcon img(String path, int w, int h) {
        return new ImageIcon(
                Toolkit.getDefaultToolkit().getImage("src/doomchit/datafiles/이미지/" + path).getScaledInstance(w, h, Image.SCALE_SMOOTH));
    }

    void errmsg(String msg) {
        JOptionPane.showMessageDialog(null, msg, "경고", JOptionPane.ERROR_MESSAGE);
    }

    void msg(String msg) {
        JOptionPane.showMessageDialog(null, msg, "정보", JOptionPane.INFORMATION_MESSAGE);
    }

    void addComp(JPanel p, JComponent c, int x, int y, int w, int h) {
        p.add(c);
        c.setBounds(x, y, w, h);
    }

    void addComp(JComponent c, int x, int y, int w, int h) {
        add(c);
        c.setBounds(x, y, w, h);
    }

    void execute(String sql) {
        try {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Base(String name, int w, int h) {
        setTitle(name);
        setSize(w, h);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);


        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

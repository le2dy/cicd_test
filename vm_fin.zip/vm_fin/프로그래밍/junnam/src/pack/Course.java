package pack;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class Course extends Base {
    JRadioButton[] r = {new JRadioButton("작접코스"),
            new JRadioButton("랜덤코스")};
    ButtonGroup bg = new ButtonGroup();
    JLabel[] img = new JLabel[10];
    JLabel[] asd = new JLabel[10];
    JPanel list = new JPanel(new GridLayout(0, 1));
    JPanel inner;
    JScrollPane scr = new JScrollPane(list);
    JLabel label;
    JButton realTime = new JButton("<html>실시간<br>줄서기</html>");
    JPanel east = new JPanel(new BorderLayout());
    JButton randyrandom = new JButton("랜덤지정");
    int tpno;
    String sel;
    int selnum;
    ArrayList<String> arr = new ArrayList<>();
    JButton confirm = new JButton("선택완료");

    public Course(int tpno) {
        setTitle("탑승코스");
        setSize(800, 700);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        this.tpno = tpno;

        label = new JLabel();
        label.setLayout(new BorderLayout());

        inner = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g;

                Image bg = img("코스지도.JPG", 600, 650).getImage();
                g2.drawImage(bg, 10, 25, null);
            }
        };

        for (int i = 0; i < r.length; i++) {
            addComp(inner, r[i], 10, 10 + (i * 25), 100, 25);
            r[i].setOpaque(false);
            r[i].addActionListener(a -> {
                if (a.getSource().equals(r[0])) {
                    randyrandom.setVisible(false);
                    realTime.setEnabled(true);
                    for (int j = 0; j < img.length; j++) {
                        img[j].setIcon(null);
                    }
                } else {
                    randyrandom.setVisible(true);
                    realTime.setEnabled(false);
                }
            });
        }

        addComp(inner, randyrandom, 90, 35, 90, 25);

        for (int i = 0; i < 3; i++) {
            img[i] = new JLabel();
            img[i + 7] = new JLabel();
            asd[i] = new JLabel();
            asd[i + 7] = new JLabel();
            addComp(inner, img[i], 160 + (i * 150), 35, 100, 100);
            addComp(inner, img[i + 7], 160 + (i * 150), 530, 100, 100);
            addComp(inner, asd[i], 160 + (i * 150), 135, 100, 25);
            addComp(inner, asd[i + 7], 160 + (i * 150), 630, 100, 25);
            img[i].setBorder(new LineBorder(Color.BLACK));
            img[i + 7].setBorder(new LineBorder(Color.BLACK));
        }

        for (int i = 0; i < 4; i++) {
            img[i + 3] = new JLabel();
            asd[i + 3] = new JLabel();
            addComp(inner, img[i + 3], 460 - (i * 150), 330, 100, 100);
            addComp(inner, asd[i + 3], 460 - (i * 150), 430, 100, 25);
            img[i + 3].setBorder(new LineBorder(Color.BLACK));
        }

        for (int i = 0; i < img.length; i++) {
            img[i].setName(i + "");
            img[i].addMouseListener(new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    JLabel tmp = (JLabel) e.getSource();
                    selnum = Integer.parseInt(tmp.getName());
                }
            });
        }

        addComp(inner, realTime, 10, 60, 80, 50);

        label.add(inner);
        add(label);

        add(east, "East");
        east.add(new JLabel("놀이기구", JLabel.CENTER), "North");
        east.add(scr);
        east.add(confirm, "South");
        east.setPreferredSize(new Dimension(200, 0));
        confirm.addActionListener(a -> {
            if (ride.size() == 0) {
                msg("놀이기구를 지정해주세요.");
                return;
            }

            msg("선택이 완료되었습니다.");
            realTime.setEnabled(true);
            int yn = JOptionPane.showConfirmDialog(null, "메인으로 이동하시곘습니까?", "메시지", JOptionPane.YES_NO_OPTION);

            if (yn == JOptionPane.YES_OPTION) {
                msg("메이폼ㅇ,로");
                dispose();
            }
        });

        realTime.addActionListener(a -> {
            msg("실시간 줄서기를 시작합니다.");
            msg("메인폼으로");

            new wating();
            dispose();
        });

        randyrandom.addActionListener(a -> {
            ride.clear();
            for (int i = 0; i < img.length; i++) {
                img[i].setIcon(null);
                asd[i].setText("");
            }

            ArrayList<String> mix = arr;
            Collections.shuffle(mix);

            for (int i = 0; i < arr.size(); i++) {
                img[i].setIcon(img(mix.get(i) + ".JPG", 100, 100));
                asd[i].setText(mix.get(i).split("/")[1]);
                ride.put(i, mix.get(i));
            }

            repaint();
            revalidate();
        });

        label.setOpaque(false);
        inner.setOpaque(false);
        realTime.setEnabled(false);
        east.setOpaque(false);
        randyrandom.setVisible(false);

        loadRides();

        getContentPane().setBackground(Color.WHITE);
        setVisible(true);
    }

    void loadRides() {
        try {
            ResultSet rs = stmt.executeQuery("select * from ride r inner join possible p on p.r_no = r.r_no where tp_no = " + tpno);
            String[] z = {"몬스타존", "에디스존", "카시아존", "플로스존"};
            while (rs.next()) {
                Temp temp = new Temp(z[rs.getInt("z_no") - 1], rs.getString("r_name"));
                arr.add(z[rs.getInt("z_no") - 1] + "/" + rs.getString("r_name"));
                list.add(temp);
                temp.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        sel = temp.z + "/" + temp.na;
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        int del = -1;

                        if (ride.containsValue(sel)) {
                            for (Map.Entry<Integer, String> a : ride.entrySet()) {
                                int key = a.getKey();
                                if (ride.get(key).equals(sel)) {
                                    del = key;
                                }
                            }
                            ride.remove(del);
                            ride.put(selnum, sel);
                        } else {
                            ride.put(selnum, sel);
                        }

                        setImages();
                    }
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void setImages() {
        for (int i = 0; i < img.length; i++) {
            if (ride.containsKey(i)) {
                img[i].setIcon(img(ride.get(i) + ".JPG", 100, 100));
                asd[i].setText(ride.get(i).split("/")[1]);
            } else {
                img[i].setIcon(null);
                asd[i].setText("");
            }
        }

        repaint();
        revalidate();
    }

    class Temp extends JPanel {
        JLabel img = new JLabel();
        JLabel name = new JLabel();
        String z, na;

        public Temp(String zone, String na) {
            setLayout(new BorderLayout());

            add(img);
            add(name, "South");

            img.setIcon(img(zone + "/" + na + ".JPG", 180, 120));
            name.setText(na);

            z = zone;
            this.na = na;
        }
    }

    public static void main(String[] args) {
        new Course(3);
    }
}

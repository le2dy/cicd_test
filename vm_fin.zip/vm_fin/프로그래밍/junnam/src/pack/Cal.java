package pack;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Cal extends Base {
    JComboBox[] combo = {
            new JComboBox(),
            new JComboBox(),
            new JComboBox(),
    };
    JButton btn = new JButton("입력");


    public Cal(JTextField txt, JComboBox f, JComboBox t, DefaultTableModel dtm, pay.input[] inputs) {
        setTitle("달력 비스무리한거");
        setSize(1000, 1000);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.CENTER));

        for (int i = 0; i < combo.length; i++) {
            add(combo[i]);
        }

        for (int i = 1900; i < 3000; i++) {
            combo[0].addItem(i+"");
        }

        for (int i = 1; i < 13; i++) {
            combo[1].addItem(i+"");
        }

        for (int i = 1; i < 32; i++) {
            combo[2].addItem(i+"");
        }

        add(btn);

        btn.addActionListener(a -> {
            txt.setText(combo[0].getSelectedItem()+"-"+ String.format("%02d",Integer.parseInt(combo[1].getSelectedItem().toString()))+"-"+String.format("%02d",Integer.parseInt(combo[2].getSelectedItem().toString())));
            f.setVisible(false);
            t.setVisible(true);
            t.setSelectedIndex(-1);
            Object[] row = {"","","",txt.getText(),""};
            dtm.setRowCount(0);
            dtm.addRow(row);
            for (int i = 0; i < inputs.length; i++) {
                inputs[i].in.setText("");
            }
            dispose();
        });

        setVisible(true);
    }
}

package pack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.*;
import java.util.Arrays;
import java.util.Scanner;

public class DB {
    static Connection con;
    static Statement stmt;
    static {
        try {
            File f =  new File("C:\\Users\\82103\\Desktop\\프로그래밍\\qwe.sqlite");

            if(f.exists()) {
                if(f.delete()) {
                    System.out.println(f.getName() + " deleted.");
                } else {
                    System.out.println(f.getName() + " are still there.");
                }
            }

            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:C:\\Users\\82103\\Desktop\\프로그래밍\\qwe.sqlite";

            con = DriverManager.getConnection(url);

            stmt = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void execute(String sql) {
        try {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void createTable(String n, String c) {
        execute("create table "+n+"("+c+")");
        //execute("load data local infile './Datafiles/"+n+".txt' into table "+n+" lines terminated by '\r\n' ignore 1 lines");
        int i = 0;
        try(Scanner scanner = new Scanner(Paths.get("src/pack/Datafiles/"+ n +".txt"))) {
            while (scanner.hasNextLine()) {
                i++;
                String line = scanner.nextLine();

                if(i == 1) continue;

                String[] data = line.split("\t");
                for(int j = 0; j < data.length; j++) {
                    data[j] = "'" + data[j] + "'";
                }
                String indata = Arrays.toString(data).replace("[","(").replace("]",")");

                execute("insert into "+n+" values"+indata);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DB() {
        createTable("user", "u_no INTEGER PRIMARY KEY AUTOINCREMENT, u_name varchar(5), u_id varchar(15), u_pw varchar(15), u_birth date, u_email varchar(150), u_point int");
        createTable("visitor", "v_no INTEGER PRIMARY KEY AUTOINCREMENT, v_name varchar(4), v_price int");
        createTable("ticket", "t_no INTEGER PRIMARY KEY AUTOINCREMENT, t_name varchar(7), t_price int, t_explanation varchar(10)");
        createTable("zone", "z_no INTEGER PRIMARY KEY AUTOINCREMENT, z_name varchar(4)");
        createTable("ride", "r_no INTEGER PRIMARY KEY AUTOINCREMENT, z_no int, r_name varchar(20), r_tall int, r_price int, r_time int, foreign key(z_no) references zone(z_no) on update cascade on delete cascade");
        createTable("ticketpay", "tp_no INTEGER PRIMARY KEY AUTOINCREMENT, u_no int, t_no int, tp_code varchar(4), tp_adult int, tp_teen int, tp_old int, tp_child int, tp_date date, tp_price int, tp_use int, foreign key(t_no) references ticket(t_no) on delete cascade on update cascade");
        createTable("possible", "p_no INTEGER PRIMARY KEY AUTOINCREMENT, tp_no int, r_no int, p_type int, p_use int, foreign key(tp_no) references ticketpay(tp_no) on delete cascade on update cascade, foreign key(r_no) references ride(r_no) on delete cascade on update cascade");
        createTable("estimation", "e_no INTEGER PRIMARY KEY AUTOINCREMENT, p_no int, e_content varchar(150), e_check int");
    }

    public static void main(String[] args) {
        new DB();
    }

}

package pack;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.TimerTask;

public class wating extends Base {
    JLabel currentStatement = new JLabel("");
    Queue<Integer> schedule = new LinkedList<>();
    String curRide;
    int curWaiting;
    int index = 0;

    public wating() {
        setTitle("대기실");
        setSize(300, 300);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(new JLabel("현재 상태"), "North");
        add(currentStatement);

        setSchedule();

        curRide = ride.get(index);
        curWaiting = schedule.poll();

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                if(!schedule.isEmpty()) {
                    if(time <= curWaiting) {
                        int asd = curWaiting - time;
                        currentStatement.setText(curRide + " : " + (asd / 60) + "분" + (asd % 60) + "초");
                        time++;
                    }
                    if(time == curWaiting){
                        time = 0;
                        index++;
                        curRide = ride.get(index);
                        curWaiting = schedule.poll();
                    }
                } else {
                    currentStatement.setText("");
                    timer.cancel();
                }

            }
        };

        timer.schedule(task, 0, 1000);

        if(time == 10) timer.cancel();

        setVisible(true);

    }

    void setSchedule() {
        try {
            ResultSet rs = null;

            for (int i = 0; i < ride.size(); i++) {
                rs = stmt.executeQuery("select r_time from ride where r_name = '" + ride.get(i) + "'");
                if (rs.next()) {
                    schedule.add(rs.getInt(1));
//                    schedule.add(5);
                }
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String[] str = "댄싱컵,G 익스프레스,썬더폴스,트위스트,제트레이스".split(",");
        for (int i = 0; i < 5; i++) {
            ride.put(i, str[i]);
        }
        new wating();
    }
}

package pack;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class pay extends Base {
    JPanel east = new JPanel(new BorderLayout());
    JPanel c = new JPanel(new BorderLayout());
    JPanel north = new JPanel(new GridLayout(0, 1));
    JPanel south = new JPanel(new GridLayout(0, 2));
    String[] str = "이용일,티켓,방문자".split(",");
    String[] age = "대인,청소년,경로,소인".split(",");
    String[] ageExp = "19세~64세,13~18세,65세 이상,0세~12세".split(",");
    JComboBox kind = new JComboBox("입장권,노멀티켓,익스프레스티켓,VIP티켓".split(","));
    JTextField dateTextField = new JTextField(10);
    JButton dateBtn = new JButton("이용일 선택");
    JButton confirm = new JButton("추가완료");
    JLabel img = new JLabel("");
    input[] inputs = new input[4];
    String dis = "";
    int curPoint = 0;
    int point = 0;
    int tot = 0;
    int atot = 0;
    int ctot = 0;
    int ttt = 0;

    DefaultTableModel dtm = new DefaultTableModel(null, "티켓명,방문자,인원수,이용일,금액".split(",")) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable table = new JTable(dtm);
    JScrollPane scr = new JScrollPane(table);
    JPanel desc = new JPanel(new BorderLayout());
    JPanel base = new JPanel(new BorderLayout());
    JPanel option = new JPanel(new BorderLayout());
    JPanel pointP = new JPanel(null);
    JPanel priceP = new JPanel(new BorderLayout());
    JPanel finalP = new JPanel(new BorderLayout());
    JLabel calc;
    DecimalFormat format = new DecimalFormat();
    JLabel fin = new JLabel("총금액:");
    JButton finBtn = new JButton("구매하기");
    JButton all = new JButton("전액사용");
    JTextField p = new JTextField(10);
    JLabel opt = new JLabel(dis);
    String[] tag = "보유,사용".split(",");
    JComboBox fake = new JComboBox("      ,      ,".split(","));
    int num = -12;

    public pay() {
        setTitle("티켓구매");
        setSize(800, 600);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);
        setLayout(null);

        addComp(base, 0, 0, 800, 560);

        base.add(c);
        base.add(east, "East");

        c.add(north, "North");
        c.add(south);

        east.add(desc, "North");
        east.add(scr);
        east.add(confirm, "South");

        desc.add(img);
        JPanel asd = new JPanel(new GridLayout(0, 1));
        JPanel qwe = new JPanel(new BorderLayout());
        desc.add(asd, "East");
        desc.add(qwe, "South");

        JLabel exp = new JLabel("<html>편의시설, 부대시설, 레스토랑, 스낵바가 구비되어 있습니다.<br>기능랜드는 업중무휴입니다.<br>구매 취소는 놀이공원 이용 5일 전 까지 가능하며<br>구매 변경은 놀이공원 이용 3일 전 까지 가능합니다.</html>");
        qwe.add(exp);
        exp.setVisible(false);

        for (int i = 0; i < str.length; i++) {
            JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel cat = new JLabel(str[i]);
            cat.setPreferredSize(new Dimension(100, 25));
            temp.add(cat);

            if (i == 0) {
                temp.add(dateTextField);
                temp.add(dateBtn);
            } else if (i == 1) {
                temp.add(fake);
                temp.add(kind);
            }

            north.add(temp);
        }

        kind.setSelectedIndex(-1);
        kind.setVisible(false);

        for (int i = 0; i < inputs.length; i++) {
            inputs[i] = new input(age[i], ageExp[i]);
            inputs[i].index = i;
            inputs[i].setPrice();
            south.add(inputs[i]);
        }

        dateBtn.addActionListener(a -> {
            new Cal(dateTextField, fake, kind, dtm, inputs);
        });

        dateTextField.setEnabled(false);
        desc.setPreferredSize(new Dimension(0, 300));
        desc.setBorder(new LineBorder(Color.BLACK));

        kind.addItemListener(a -> {
            if (num == -12) {
                for (int i = 0; i < inputs.length; i++) {
                    inputs[i].in.setText("");
                    inputs[i].setPrice();
                }
                dtm.setRowCount(0);
                img.setIcon(img(kind.getSelectedItem() + "로고.jpg", 225, 200));
                exp.setVisible(true);
                try {
                    ResultSet rs = stmt.executeQuery("select * from ticket where t_no = " + (kind.getSelectedIndex() + 1));
                    if (rs.next()) {
                        asd.add(new JLabel(rs.getString("t_name")));
                        asd.add(new JLabel(new DecimalFormat().format(rs.getInt("t_price")) + "원 추가금액 발생"));
                        asd.add(new JLabel(rs.getString(4)));
                        rs.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                repaint();
                revalidate();
            } else {

            }
        });

        confirm.addActionListener(a -> {
            String str = "";
            for (int i = 0; i < inputs.length; i++) {
                str += inputs[i].in.getText();
            }
            if (str.isEmpty() || !kind.isVisible() || kind.getSelectedIndex() == -1) {
                errmsg("빈칸이 있습니다.");
                return;
            }
            setSize(800, 900);
            for (int i = 0; i < table.getRowCount(); i++) {
                tot += Integer.parseInt(table.getValueAt(i, 4).toString().replace(",", ""));
            }

            calc.setText(format.format(tot) + "-" + format.format(point) + "=" + format.format((tot - point)));
            fin.setText("총금액  ￦" + format.format(tot));
            repaint();
            revalidate();
        });

        addComp(option, 0, 600, 800, 250);
        option.add(pointP, "West");
        option.add(priceP);
        option.add(finalP, "East");

        pointP.setBorder(new LineBorder(Color.RED));
        priceP.setBorder(new LineBorder(Color.BLUE));
        finalP.setBorder(new LineBorder(Color.BLACK));

        addComp(pointP, new JLabel("할인 및 포인트"), 10, 10, 100, 25);
        opt.setBorder(new LineBorder(Color.BLACK));
        addComp(pointP, opt, 10, 30, 100, 100);
        ;

        try {
            ResultSet rs = stmt.executeQuery("select u_point from user where u_no = " + NO);
            if (rs.next()) {
                curPoint = rs.getInt(1);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        p.setHorizontalAlignment(JTextField.RIGHT);
        p.setText("p");
        for (int i = 0; i < tag.length; i++) {
            JPanel temp = new JPanel(new FlowLayout());
            JLabel a = new JLabel(tag[i]);
            a.setPreferredSize(new Dimension(50, 25));
            temp.add(a);

            if (i == 0) {
                temp.add(new JLabel(new DecimalFormat().format(curPoint) + "p"));
                temp.add(all);
            } else {
                temp.add(p);
            }

            addComp(pointP, temp, 110, 40 + (i * 40), 200, 35);
        }

        all.addActionListener(e -> {
            p.setText(this.curPoint + "p");
            point = curPoint;
            if (num == -12) {
                calc.setText(format.format(tot) + "-" + format.format(curPoint) + "=" + format.format((tot - curPoint)));
                fin.setText("총금액  ￦" + format.format(tot - curPoint));
            } else {
                calc.setText(format.format(ctot) + "-" + format.format(curPoint) + "=" + format.format((ctot - curPoint)));
                fin.setText("총금액  ￦" + format.format(ctot - curPoint));
            }
        });

        calc = new JLabel("");
        priceP.add(calc);

        p.addKeyListener(new KeyAdapter() {

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() >= 49 && e.getKeyCode() <= 58) {
                    String ert = p.getText().replace("p", "");
                    ert += "p";
                    p.setText(ert);
                    point = Integer.parseInt(p.getText().replace("p", ""));
                    calc.setText(format.format(tot) + "-" + format.format(point) + "=" + format.format((tot - point)));
                    fin.setText("총금액  ￦" + format.format(tot - point));
                }
            }
        });

        finalP.add(fin);
        finalP.add(finBtn, "South");

        finBtn.addActionListener(a -> {
            if (num == -12) {
                msg("구매가 완료되었습니다.\n포인트가 지급되었습니다.");
                int po = (int) ((tot - point) * 0.03);

                String code = "'";
                Random random = new Random();
                code = ((char) (random.nextInt(26) + 65)) + (random.nextInt(10)) + ((char) (random.nextInt(26) + 65)) + (random.nextInt(10)) + "";

                execute("update user set u_point = u_point + " + po + " where u_no = " + NO);
                execute("insert into ticketpay values(0," + NO + "','" + (kind.getSelectedIndex() + 1) + "','" + code + "','" + inputs[0].in.getText() + "','" + inputs[1].in.getText() + "','" + inputs[2].in.getText() + "','" + inputs[3].in.getText() + "','" + LocalDate.now() + "','" + (tot - point) + "',0)");
                int yn = JOptionPane.showConfirmDialog(null, "티켓을 확인하겠습니까?", "메시지", JOptionPane.YES_NO_OPTION);
                int num = 0;
                try {
                    ResultSet rs = stmt.executeQuery("select count(*) from ticketpay");
                    if (rs.next()) num = rs.getInt(1);
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (yn == JOptionPane.YES_OPTION) {
                    TICKET_CODE = num;
                    new Ticket();
                    dispose();
                } else {
                    msg("메인으로");
                    dispose();
                }
            } else {
                try {
                    ResultSet rs = stmt.executeQuery("select * from ticketpay where tp_no = " + num + " and t_no = " + (kind.getSelectedIndex() + 1) + " and tp_date = '" + dateTextField.getText() + "' and tp_adult = " + inputs[0].in.getText() + " and tp_teen = " + inputs[1].in.getText() + " and tp_old = " + inputs[2].in.getText() + " and tp_child = " + inputs[3].in.getText());
                    if(rs.next()) {
                        int yn = JOptionPane.showConfirmDialog(null, "변경된 내용이 없습니다. 티켓 폼으로 이동하시겠습니까?", "메시지", JOptionPane.YES_NO_OPTION);

                        if(yn == JOptionPane.YES_OPTION) {
                            TICKET_CODE = num;
                            new Ticket();
                            dispose();
                        }
                    } else {
                        execute("update ticketpay set tp_adult = '"  + inputs[0].in.getText() + "', tp_teen = '" + inputs[1].in.getText() + "', tp_old = '" + inputs[2].in.getText() + "', tp_child = '" + inputs[3].in.getText() +"', tp_date = '" + dateTextField.getText() + "', tp_price = '" + ctot + "' where tp_no = " + num);
                        msg("변경이 완료되었습니다.");
                        TICKET_CODE = num;
                        new Ticket();
                        dispose();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });

        pointP.setPreferredSize(new Dimension(320, 0));
        finalP.setPreferredSize(new Dimension(300, 0));

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public pay(int num) {
        this();
        this.num = num;
        setSize(800, 900);
        setTitle("티켓변경");

        fake.setVisible(false);
        kind.setVisible(true);
        finBtn.setText("변경하기");

        kind.addActionListener(a -> {
            ctot = 0;
            for (int i = 0; i < inputs.length; i++) {
                inputs[i].setPrice();
            }

            ArrayList<String> ageList = new ArrayList<>();
            Arrays.stream(age).forEach(p -> {
                ageList.add(p);
            });
            ;

            for (int i = 0; i < table.getRowCount(); i++) {
                table.setValueAt(kind.getSelectedItem(), i, 0);
                for (int j = 0; j < inputs.length; j++) {
                    int idx = ageList.indexOf(table.getValueAt(i, 1));
                    int pr = Integer.parseInt(inputs[idx].price.getName()) * Integer.parseInt(inputs[idx].in.getText());
                    table.setValueAt(format.format(pr), i, 4);
                }
                ctot += Integer.parseInt(table.getValueAt(i, 4).toString().replace(",", ""));
                calc.setText(format.format(ctot) + "-" + format.format(point) + "=" + format.format((ctot - point)));
                fin.setText("총금액  ￦" + format.format(ctot - point));
            }

            String finTxt = "<html>" + format.format(atot) + "-" + format.format(ctot) + "<br>";
            String extra = "";
            if (atot > ctot) {
                extra = "환급금  ￦" + format.format((atot - ctot));
            } else if (atot < ctot) {
                extra = "추가금  ￦" + format.format((-(atot - ctot)));
            } else {
                extra = "추가금  ￦0";
            }
            finTxt += extra;
            fin.setText(finTxt);

            ttt = atot - ctot;
        });
        try {
            ResultSet rs = stmt.executeQuery("select * from ticketpay where tp_no = " + num);
            if (rs.next()) {
                dateTextField.setText(rs.getString("tp_date"));
                for (int i = 0; i < inputs.length; i++) {
                    inputs[i].in.setText(rs.getString(i + 5).equals("0") ? "" : rs.getString(i + 5));
                    if (rs.getInt(i + 5) != 0) {
                        int t = Integer.parseInt(inputs[i].price.getName()) * rs.getInt(i + 5);
                        Object[] row = {kind.getItemAt(rs.getInt("t_no") - 1), age[i], rs.getInt(i + 5), rs.getString("tp_date"), format.format(t)};
                        dtm.addRow(row);
                    }
                }
                atot = rs.getInt("tp_price");
                kind.setSelectedIndex(rs.getInt("t_no") - 1);
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        p.addKeyListener(new KeyAdapter() {

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() >= 49 && e.getKeyCode() <= 58) {
                    String ert = p.getText().replace("p", "");
                    ert += "p";
                    p.setText(ert);
                    point = Integer.parseInt(p.getText().replace("p", ""));
                    calc.setText(format.format(ctot) + "-" + format.format(point) + "=" + format.format((ctot - point)));
                    fin.setText("총금액  ￦" + format.format(tot - point));
                }
            }
        });

        calc.setText(format.format(atot) + "-" + format.format(ctot) + "=" + format.format(atot - ctot));

    }

    class input extends JPanel {
        JLabel board = new JLabel("", JLabel.CENTER);
        JLabel price = new JLabel("", JLabel.CENTER);
        JTextField in = new JTextField();
        int index;
        int[] aprice = {26000, 22000, 20000, 18000};
        int[] tprice = {0, 30000, 50000, 100000};

        void setPrice() {
            double discount = 0;
            LocalDate date = LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 1);
            int dow = date.getDayOfWeek().getValue();
            if (dow == 1 || dow == 2 || dow == 5 || dow == 7) {
                discount = 0.9;
                dis = "10% 할인";
            } else if (dow == 3 || dow == 4) {
                discount = 0.8;
                dis = "20% 할인";
            } else {
                dis = "할인혜택 없음";
            }

            opt.setText(dis);

            int tn = kind.getSelectedIndex() == -1 ? 0 : kind.getSelectedIndex();
            price.setText(format.format(((aprice[index] + tprice[tn])) * discount) + "원");
            price.setName((int) ((aprice[index] + tprice[tn]) * discount) + "");
        }

        public input(String k, String l) {
            setLayout(new BorderLayout());

            add(board, "North");
            add(price);
            add(in, "South");

            board.setPreferredSize(new Dimension(0, 100));
            board.setBorder(new LineBorder(Color.BLACK));
            setLayout(new BorderLayout());

            add(board, "North");
            add(price);
            add(in, "South");

            board.setPreferredSize(new Dimension(0, 100));
            board.setBorder(new LineBorder(Color.BLACK));

            board.setText("<html>" + k + "<br>" + "(만 " + l + ")");

            in.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    if (in.getText().matches(".*[0-9].*")) {
                        int r = -1;

                        for (int i = 0; i < table.getRowCount(); i++) {
                            if (table.getValueAt(i, 1).equals(k)) {
                                r = i;
                            }
                        }

                        double discount = 0;
                        LocalDate date = LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 1);
                        int dow = date.getDayOfWeek().getValue();
                        if (dow == 1 || dow == 2 || dow == 5 || dow == 7) {
                            discount = 0.9;
                            dis = "10% 할인";
                        } else if (dow == 3 || dow == 4) {
                            discount = 0.8;
                            dis = "20% 할인";
                        } else {
                            dis = "할인혜택 없음";
                        }

                        opt.setText(dis);

                        int totprice = (int) ((aprice[index] + tprice[kind.getSelectedIndex()]) * discount * Integer.parseInt(in.getText()));

                        if (r != -1) {
                            table.setValueAt(in.getText(), r, 2);
                            table.setValueAt(format.format(totprice), r, 4);
                        } else {
                            Object[] row = {kind.getSelectedItem().toString(), k, e.getKeyChar(), dateTextField.getText(), format.format(totprice)};
                            if (table.getRowCount() == 1 && table.getValueAt(0, 1).equals("")) {
                                for (int i = 0; i < row.length; i++) {
                                    table.setValueAt(row[i], 0, i);
                                }
                            } else {
                                dtm.addRow(row);
                            }
                        }

                        tot = 0;
                        ctot = 0;

                        for (int i = 0; i < table.getRowCount(); i++) {
                            tot += Integer.parseInt(table.getValueAt(i, 4).toString().replace(",", ""));
                            ctot += Integer.parseInt(table.getValueAt(i, 4).toString().replace(",", ""));
                        }

                        if (num == -12) {
                            calc.setText(format.format(tot) + "-" + format.format(point) + "=" + format.format((tot - point)));
                            fin.setText("총금액  ￦" + format.format(tot));
                        } else {
                            calc.setText(format.format(ctot) + "-" + format.format(point) + "=" + format.format((ctot - point)));
                            String finTxt = "<html>" + format.format(atot) + "-" + format.format(ctot) + "<br>";
                            String extra = "";
                            if (atot > ctot) {
                                extra = "환급금  ￦" + format.format((atot - ctot));
                            } else if (atot < ctot) {
                                extra = "추가금  ￦" + format.format((-(atot - ctot)));
                            } else {
                                extra = "추가금  ￦0";
                            }
                            finTxt += extra;
                            fin.setText(finTxt);

                            ttt = atot - ctot;
                        }

                    } else {
                        if (in.getText().isEmpty()) {
                            for (int i = 0; i < table.getRowCount(); i++) {
                                if (table.getValueAt(i, 1).equals(k)) dtm.removeRow(i);
                            }

                            if (table.getRowCount() == 0) {
                                Object row[] = {kind.getSelectedItem().toString(), "", "", dateTextField.getText(), ""};
                                dtm.addRow(row);
                                calc.setText("0-0=0");
                                fin.setText("총금액  ￦0");
                            }
                            return;
                        }
                        errmsg("숫자로 입력해주세요.");
                        in.setText("");
                        in.requestFocus();
                    }
                }
            });
        }
    }

    public static void main(String[] args) {
        new pay(1);
    }
}

package pack;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class admin extends Base {
    JComboBox<String> combo = new JComboBox("전체,몬스타존,에디스존,플로스존,카시아존".split(","));
    JPanel inner = new JPanel(new GridLayout(0, 2));
    JScrollPane scr = new JScrollPane(inner);
    DefaultTableModel dtm = new DefaultTableModel(null, ",회원,날짜,평가내용,e_no".split(",")) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return column == 0;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return JComponent.class;
        }
    };

    DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (column == 0) {
                JCheckBox a = (JCheckBox) value;
                a.setOpaque(false);
                return a;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    };
    JTable table = new JTable(dtm);
    JScrollPane scrT = new JScrollPane(table);
    JPanel north = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JPanel south = new JPanel(new BorderLayout());
    JButton confirm = new JButton("확인완료");
    ArrayList<Temp> arr = new ArrayList<>();
    int sel;

    public admin() {
        setTitle("관리자");
        setSize(500, 600);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);

        add(north, "North");
        add(scr);
        add(south, "South");

        north.add(combo);

        south.add(scrT);
        south.add(confirm, "South");

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(dtcr);
        }

        loadRides();

        table.getTableHeader().addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if(e.getClickCount() == 2 && table.columnAtPoint(e.getPoint()) == 0) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        JCheckBox qwe = (JCheckBox) table.getValueAt(i, 0);
                        qwe.setSelected(true);
                        table.setValueAt(qwe, i, 0);
                    }
                }
            }
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {;
                if (table.getSelectedRow() != -1 || table.getSelectedColumn() == 0) {
                    JCheckBox qwe = (JCheckBox) table.getValueAt(table.getSelectedRow(), 0);
                    if (qwe.isSelected()) {
                        qwe.setSelected(false);
                    } else {
                        qwe.setSelected(true);
                    }
                    table.setValueAt(qwe, table.getSelectedRow(), 0);
                }
            }
        });

        combo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                loadRides();
            }
        });

        confirm.addActionListener(a -> {
            int check = 0;
            ArrayList<String> eno = new ArrayList<>();
            for (int i = 0; i < table.getRowCount(); i++) {
                JCheckBox q = (JCheckBox) table.getValueAt(i, 0);
                if(q.isSelected()) {
                    check++;
                    eno.add(table.getValueAt(i, 4).toString());
                }
            }

            if(check == 0) {
                errmsg("선택한 평가내용이 없습니다.");
                return;
            }

            msg("확인이 완료되었습니다.");

            for (int i = 0; i < eno.size(); i++) {
                execute("update estimation set e_check = 1 where e_no = " + eno.get(i));
            }

            msg("로그인 폼으로");
            dispose();
        });

        south.setPreferredSize(new Dimension(0, 200));

        setVisible(true);
    }

    void loadRides() {
        inner.removeAll();
        arr.clear();

        String z = combo.getSelectedIndex() == 0 ? "1=1" : "z_no = " + combo.getSelectedIndex();
        try {
            ResultSet rs = stmt.executeQuery("select * from ride where " + z);
            String[] str = "'',몬스타존,에디스존,카시아존,플로스존".split(",");
            while (rs.next()) {
                Temp temp = new Temp(str[rs.getInt("z_no")], rs.getString("r_name"));
                inner.add(temp);
                temp.setName(rs.getString("r_no"));
                temp.setBorder(Color.BLACK, 1);
                arr.add(temp);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        arr.get(0).setBorder(Color.RED, 2);
        sel = Integer.parseInt(arr.get(0).getName());
        loadEstimation(sel);
    }

    void loadEstimation(int rno) {
        dtm.setRowCount(0);

        try {
            ResultSet rs = stmt.executeQuery("select * from estimation e inner join possible p on e.p_no = p.p_no inner join ticketpay t on p.tp_no = t.tp_no inner join user u on t.u_no = u.u_no where e_check = 0 and p.r_no = " + sel + " order by tp_date");
            while (rs.next()) {
                String name = rs.getString("u_name");
                Object[] row = {new JCheckBox(), name.replace(name.charAt(1), '*'), rs.getString("tp_date"), rs.getString("e_content"), rs.getInt("e_no")};
                dtm.addRow(row);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    class Temp extends JPanel {
        JLabel img = new JLabel("");
        JLabel name = new JLabel("", JLabel.CENTER);

        public Temp(String zone, String na) {
            setLayout(new BorderLayout());
            add(img);
            img.setIcon(img(zone + "/" + na + ".JPG", 100, 100));
            add(name, "South");
            name.setText(na);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    for (int i = 0; i < arr.size(); i++) {
                        arr.get(i).setBorder(Color.BLACK, 1);
                    }
                    sel = Integer.parseInt(getName());
                    setBorder(Color.RED, 2);
                    loadEstimation(sel);
                }
            });
        }

        void setBorder(Color col, int thick) {
            setBorder(new LineBorder(col, thick));
        }
    }

    public static void main(String[] args) {
        new admin();
    }
}

package pack;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;

public class Ticket extends Base {
    JPanel c = new JPanel();
    JButton prev = new JButton("<"), next = new JButton(">");
    JLabel label, gradeLabel = new JLabel();
    JPanel personal = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel totalPriceLabel = new JLabel("", JLabel.RIGHT);
    JLabel deadlineLabel = new JLabel();
    JLabel serialLabel = new JLabel("", JLabel.CENTER);
    JLabel old = new JLabel();
    JLabel teen = new JLabel();
    JLabel adult = new JLabel();
    JLabel child = new JLabel();
    JButton confirm = new JButton("확인완료");
    JPanel inner, south = new JPanel(new FlowLayout(FlowLayout.CENTER));
    int index = 0;
    int row = -1;
    ArrayList<Integer> ticketList = new ArrayList<>();
    String kind = "노멀티켓";
    ticket asd;
    JButton cancel = new JButton("구매취소");
    JButton change = new JButton("구매변경");
    JButton ok = new JButton("확인완료");

    boolean isPossible = false;

    DefaultTableModel dtm = new DefaultTableModel(null, "티켓번호,티켓명,방문자,인원수,이용일,금액,asdads".split(",")) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return JComponent.class;
        }
    };

    DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return (JLabel) value;
        }
    };
    JTable table = new JTable(dtm);
    JScrollPane scr = new JScrollPane(table);

    public Ticket() {
        setTitle("pack.Ticket");
        setSize(800, 350);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);

        if (TICKET_CODE == -1) {
            loadTickets();
            loadTicket(ticketList.get(index));
        } else {
            loadTicket(TICKET_CODE);
        }

        JLabel today = new JLabel("TODAY'S TICKET");
        add(today, "North");
        add(c);

        label = new JLabel();
        label.setLayout(new BorderLayout());

        inner = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g;

                Image bg = img(kind + ".jpg", 650, 250).getImage();
                g2.drawImage(bg, 0, 0, null);
            }
        };

        addComp(inner, new JLabel("기능랜드 티켓"), 40, 70, 100, 25);
        addComp(inner, new JLabel("TICKET", JLabel.RIGHT), 300, 70, 100, 25);

        gradeLabel.setFont(new Font("", Font.BOLD, 25));
        totalPriceLabel.setFont(new Font("", Font.BOLD, 25));
        serialLabel.setFont(new Font("", Font.BOLD, 20));

        addComp(inner, gradeLabel, 40, 130, 200, 25);
        addComp(inner, personal, 40, 150, 100, 80);
        addComp(inner, new JLabel(kind, JLabel.RIGHT), 320, 110, 80, 25);
        addComp(inner, totalPriceLabel, 250, 130, 150, 25);
        addComp(inner, deadlineLabel, 280, 150, 150, 25);
        addComp(inner, serialLabel, 500, 130, 130, 30);
        addComp(inner, new JLabel("기능랜드 티켓", JLabel.CENTER), 500, 160, 130, 30);
        addComp(inner, new JLabel("TICKET", JLabel.CENTER), 500, 190, 130, 30);

        personal.add(adult);
        personal.add(teen);
        personal.add(old);
        personal.add(child);

        adult.setVisible(false);
        teen.setVisible(false);
        old.setVisible(false);
        child.setVisible(false);

        label.add(inner);
        label.setPreferredSize(new Dimension(650, 250));
        scr.setPreferredSize(new Dimension(650, 250));

        c.add(prev);
        c.add(label);
        c.add(scr);
        c.add(next);
        scr.setVisible(false);

        add(south, "South");

        south.add(confirm);

        personal.setOpaque(false);
        south.setOpaque(false);
        c.setOpaque(false);

        prev.setEnabled(false);
        if (TICKET_CODE != -1 || ticketList.size() == 1) {
            next.setEnabled(false);
        }

        prev.addActionListener(a -> {
            index--;
            if (index == 0) prev.setEnabled(false);
            loadTicket(ticketList.get(index));
            next.setEnabled(true);
        });

        next.addActionListener(a -> {
            index++;
            if (index == ticketList.size() - 1) next.setEnabled(false);
            loadTicket(ticketList.get(index));
            prev.setEnabled(true);
        });

        JComponent comp[] = {cancel, change, ok};

        for (int i = 0; i < comp.length; i++) {
            south.add(comp[i]);
            comp[i].setVisible(false);
        }

        confirm.addActionListener(a -> {
            label.setVisible(false);
            scr.setVisible(true);
            confirm.setVisible(false);
            for (int i = 0; i < comp.length; i++) {
                comp[i].setVisible(true);
            }
            loadTable();
            repaint();
            revalidate();
        });

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(dtcr);
        }
        table.getColumnModel().getColumn(table.getColumnCount() - 1).setMinWidth(0);
        table.getColumnModel().getColumn(table.getColumnCount() - 1).setMaxWidth(0);

        cancel.addActionListener(a -> {
            JLabel jkjk = (JLabel) table.getValueAt(table.getSelectedRow(), 4);
            LocalDate deadline = LocalDate.parse((CharSequence) jkjk.getText());
            if (deadline.minusDays(5).equals(LocalDate.now())) {
                errmsg("못함");
                return;
            }
            if (row == -1) {
                errmsg("취소할 항목을 선택하세요.");
            } else {
                if (isPossible) {
                    msg("구매취소가 완료되었습니다.");
                    JLabel b = (JLabel) table.getValueAt(table.getSelectedRow(), table.getColumnCount() - 1);
                    int num = Integer.parseInt(b.getText());
                    execute("delete from ticketpay where tp_no = " + num);
                } else {
                    errmsg("구매취소가 불가능합니다.");
                    return;
                }

                loadTable();
            }
        });

        change.addActionListener(a -> {
            JLabel jkjk = (JLabel) table.getValueAt(table.getSelectedRow(), 4);
            LocalDate deadline = LocalDate.parse((CharSequence) jkjk.getText());
            if (deadline.minusDays(3).equals(LocalDate.now())) {
                errmsg("못함");
                return;
            }
            if (row == -1) {
                errmsg("취소할 항목을 선택하세요.");
            } else {
                if (isPossible) {
                    JLabel b = (JLabel) table.getValueAt(table.getSelectedRow(), table.getColumnCount() - 1);
                    int num = Integer.parseInt(b.getText());
                    new pay(num);
                } else {
                    errmsg("구매변경이 불가능합니다.");
                    return;
                }

                loadTable();
            }
        });

        ok.addActionListener(a -> {
            dispose();
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (table.getSelectedRow() != -1) {
                    row = table.getSelectedRow();
                    JLabel a = (JLabel) table.getValueAt(table.getSelectedRow(), 0);
                    if (a.getName().equals("true")) {
                        isPossible = true;
                        cancel.setEnabled(true);
                        change.setEnabled(true);
                    } else {
                        isPossible = false;
                        cancel.setEnabled(false);
                        change.setEnabled(false);
                    }
                }
            }
        });

        setData();

        getContentPane().setBackground(Color.WHITE);
        setVisible(true);
    }

    void loadTable() {
        dtm.setRowCount(0);

        try {
            ResultSet rs = stmt.executeQuery("select * from ticketpay where tp_date is not date('now') and u_no = " + NO);
            String[] str = {"입장권", "노멀티켓", "익스프레스티켓", "VIP티켓"};
            String[] str2 = "성인,청소년,경로,소인".split(",");
            int idx = 1;
            while (rs.next()) {
                Object row[] = {idx, str[rs.getInt("t_no") - 1], null, null, rs.getString("tp_date"), new DecimalFormat().format(rs.getInt("tp_price")), rs.getInt("tp_no")};
                int pr = rs.getInt("tp_adult") + rs.getInt("tp_teen") + rs.getInt("tp_child") + rs.getInt("tp_old");
                ArrayList<String> qwe = new ArrayList<>();
                for (int i = 0; i < 4; i++) {
                    if (rs.getInt(5 + i) != 0) {
                        qwe.add(str2[i]);
                    }
                }
                boolean use = rs.getBoolean("tp_use");

                String aa = String.join(",", qwe);
                row[2] = aa.replace(",,", ",");
                row[3] = pr;

                Object irow[] = new Object[row.length];

                for (int i = 0; i < irow.length; i++) {
                    String content = row[i].toString();
                    irow[i] = new JLabel("", JLabel.CENTER);
                    ((JLabel) irow[i]).setName("true");
                    if (use || LocalDate.now().isAfter(LocalDate.parse((CharSequence) row[4]))) {
                        content = "<html><a style='color: red; text-decoration: line-through;font-weight: normal;'>" + content + "</a></html>";
                        ((JLabel) irow[i]).setName("false");
                    }

                    ((JLabel) irow[i]).setText(content);
                }

                dtm.addRow(irow);

                idx++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    void setData() {
        gradeLabel.setText(kind);
        DecimalFormat format = new DecimalFormat();
        totalPriceLabel.setText(format.format(asd.totprice) + "원");
        adult.setText("대인(" + asd.adult + ")");
        teen.setText("청소년(" + asd.teen + ")");
        old.setText("경로(" + asd.old + ")");
        child.setText("소인(" + asd.child + ")");
        deadlineLabel.setText("유효기간: " + asd.date);
        serialLabel.setText(asd.code);

        if (asd.adult != 0) adult.setVisible(true);
        if (asd.teen != 0) teen.setVisible(true);
        if (asd.old != 0) old.setVisible(true);
        if (asd.child != 0) child.setVisible(true);

        repaint();
        revalidate();
    }

    void loadTickets() {
        try {
            ResultSet rs = stmt.executeQuery("select * from ticketpay where u_no = " + NO /*+ " and tp_date = date('now')"*/);
            while (rs.next()) {
                ticketList.add(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void loadTicket(int no) {
        ticket t = new ticket();
        try {
            int tno = -1;
            ResultSet rs = stmt.executeQuery("select * from ticketpay where tp_no = " + no);
            if (rs.next()) {
                tno = rs.getInt("t_no");
                t.code = rs.getString("tp_code");
                t.adult = rs.getInt("tp_adult");
                t.child = rs.getInt("tp_child");
                t.old = rs.getInt("tp_old");
                t.teen = rs.getInt("tp_teen");
                t.date = LocalDate.parse((CharSequence) rs.getString("tp_date"));
                t.totprice = rs.getInt("tp_price");
                t.use = rs.getBoolean("tp_use");

                String str = "";
                for (int i = 0; i < rs.getMetaData().getColumnCount() - 1; i++) {
                    str += rs.getString(i + 1) + ",";
                }
                rs.close();
            }

            rs = stmt.executeQuery("select * from ticket where t_no = " + tno);
            if (rs.next()) {
                kind = rs.getString(2);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        asd = t;
        setData();
    }

    class ticket {
        String code;
        int adult;
        int teen;
        int old;
        int child;
        LocalDate date;
        int totprice;
        boolean use;
    }

    public static void main(String[] args) {
        new Ticket();
    }

}
package pack;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class nolegigu extends Base {
    JComboBox zone = new JComboBox("전체,몬스타존,에디스존,플로스존,카시아존".split(","));
    JSlider slider = new JSlider(90, 180);
    JLabel count = new JLabel("0/0");
    JButton search = new JButton("조회");
    JButton refresh = new JButton("빙글빙글");
    JPanel north = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JButton confirm = new JButton("선택완료");
    JPanel inner = new JPanel(new GridLayout(0, 3));
    JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JScrollPane scr = new JScrollPane(inner);
    JLabel tall = new JLabel();
    ArrayList<Integer> sel = new ArrayList<>();
    ArrayList<Ride> rlist = new ArrayList<>();
    int max = 0;
    int tno;
    int tpno;

    public nolegigu(int tpno) {
        //tno는 티켓 반호
        setTitle("놀이기구");
        setSize(700, 600);
        setDefaultCloseOperation(2);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        this.tpno = tpno;

        try {
            ResultSet rs = stmt.executeQuery("select t_no from ticketpay where tp_no = " + tpno);
            System.out.println("select t_no from ticketpay where tp_no = " + tpno);
            if (rs.next()) {
                tno = rs.getInt(1);
                System.out.println(tno);
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        add(north, "North");
        add(scr);
        add(south, "South");

        slider.setMajorTickSpacing(30);
        slider.setMinorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setValue(90);

        slider.addChangeListener(a -> {
            tall.setText("<html>키에 맞는 놀이기구<br>" + slider.getValue() + "cm</html>");
            if (slider.getValue() == 90) {
                tall.setText("<html>키에 맞는 놀이기구<br>0cm</html>");
            }
        });

        north.add(count);
        north.add(new JLabel("지역별 찾기"));
        north.add(zone);
        north.add(tall);
        north.add(slider);
        north.add(search);
        north.add(refresh);

        if (tno == 1) {
            max = 9999;
        } else if (tno == 2) {
            max = 3;
        } else if (tno == 3) {
            max = 5;
        } else if (tno == 4) {
            max = 9999;
        }

        if (max == 9999) {
            count.setText("자유이용");
        } else {
            count.setText(0 + "/" + max);
        }

        tall.setText("<html>키에 맞는 놀이기구<br>0cm</html>");

        south.add(confirm);

        search.addActionListener(a -> {
            loadRides();
        });

        refresh.addActionListener(a -> {
            zone.setSelectedIndex(0);
            slider.setValue(90);
            for (int i = 0; i < rlist.size(); i++) {
                rlist.get(i).setBorder(new LineBorder(Color.BLACK));
            }
            loadRides();
        });

        confirm.addActionListener(a -> {
            if (sel.size() == 0) {
                errmsg("놀이기구를 선탣해주세요.");
                return;
            }

            if(tno == 0) {
                int yn = JOptionPane.showConfirmDialog(null, "소유하고 계신 이용권으로는 놀이기구 탑승이 불가능합니다.\n놓이기구를 결제하시겠습니까? (추가비용이 발생합니다.)", "매사지", JOptionPane.YES_NO_OPTION);

                if(yn == JOptionPane.YES_OPTION) {
                    msg("놀이기구 결제 폼으로");
                    dispose();
                }
            }

            ArrayList<String> arr = new ArrayList<>();
            ArrayList<String> zxc = new ArrayList<>();
            try {
                ResultSet rs = stmt.executeQuery("select * from possible where tp_no = " + this.tpno);
                while(rs.next()) {
                    for (int i = 0; i < sel.size(); i++) {
                        if(rs.getInt("r_no") == sel.get(i) && rs.getInt("p_use") == 1) arr.add(rs.getString("r_no"));
                    }
                }

                for (int i = 0; i <arr.size(); i++) {
                    rs = stmt.executeQuery("select r_name from ride where r_no = " + arr.get(i));
                    if(rs.next()) zxc.add(rs.getString(1));
                }
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            if(arr.size() > 0) {
                String qwe = String.join(", ", arr);
                errmsg(qwe + "은 이미 탑승 가능하여 선택이 불가능합니다.");
                return;
            }

            msg("선탣이 완료되었습니다.");
            for (int i = 0; i < arr.size(); i++) {
                execute("insert into possible values(0,'"+this.tpno+"','"+zxc.get(i)+"','0','0')");
            }
            new Course(this.tpno);
            dispose();
        });

        loadRides();

        setVisible(true);
    }

    void loadRides() {
        inner.removeAll();
        rlist.clear();
        sel.clear();

        String z = zone.getSelectedIndex() == 0 ? "1=1" : "z_no = " + zone.getSelectedIndex();
        String t = slider.getValue() == 90 ? "1=1" : "r_tall <=" + slider.getValue();

        try {
            ResultSet rs = stmt.executeQuery("select * from ride where " + z + " and " + t);
            while (rs.next()) {
                Ride r = new Ride(rs.getString("r_no"));
                r.setBorder(new LineBorder(Color.BLACK));
                inner.add(r);
                rlist.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < rlist.size(); i++) {
            rlist.get(i).setData(Integer.parseInt(rlist.get(i).getName()));
        }

        repaint();
        revalidate();
    }

    class Ride extends JPanel {
        JLabel img = new JLabel("");
        JLabel name = new JLabel("놀이귀그");
        JLabel zone = new JLabel("지역:");
        JLabel limit = new JLabel("이용제한:");
        JLabel price = new JLabel("탑승비:");
        JLabel time = new JLabel("시간:");
        JPanel list = new JPanel(new GridLayout(0, 1));
        boolean selected = false;

        public Ride(String no) {
            setLayout(new BorderLayout());

            add(img, "North");
            img.setPreferredSize(new Dimension(200, 80));

            add(name);
            add(list, "South");
            list.add(zone);
            list.add(limit);
            list.add(price);
            list.add(time);
            this.setName(no);
            selected = false;

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseReleased(MouseEvent e) {
                    Ride asd = (Ride) e.getSource();

                    if (sel.size() == max) {
                        errmsg("자유 탑승 가능한 놀이기구의 선택 개수가 초과되었습니다.");
                        return;
                    }

                    if (selected) {
                        asd.setBorder(new LineBorder(Color.BLACK));
                        sel.remove(sel.indexOf(Integer.parseInt(asd.getName())));
                    } else {
                        asd.setBorder(new LineBorder(Color.RED));
                        sel.add(Integer.parseInt(asd.getName()));
                    }
                    selected = !selected;
                    count.setText(sel.size() + "/" + max);
                }
            });
        }

        void setData(int rno) {
            try {
                ResultSet rs1 = stmt.executeQuery("select * from ride r inner join zone z on r.z_no = z.z_no where r_no = " + rno);
                if (rs1.next()) {
                    img.setIcon(img(rs1.getString("z_name") + "/" + rs1.getString("r_name") + ".JPG", 200, 80));
                    name.setText(rs1.getString("r_name"));
                    zone.setText("지역: " + rs1.getString("z_name"));
                    limit.setText("이용제한: " + rs1.getString("r_tall") + "cm 이상");
                    price.setText("탑승비: " + new DecimalFormat().format(rs1.getInt("r_price")) + "원");
                    int m = rs1.getInt("r_time") / 60;
                    int s = rs1.getInt("r_time") % 60;
                    time.setText("시간: " + m + "분 " + s + "초");
                }

                rs1.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new nolegigu(1);
    }
}

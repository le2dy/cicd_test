package pack;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {
        Connection con = null;

        try {
            File f =  new File("C:\\Users\\김지온\\Desktop\\프로그래밍\\qwe.sqlite");

            if(f.exists()) {
                if(f.delete()) {
                    System.out.println(f.getName() + " deleted.");
                } else {
                    System.out.println(f.getName() + " are still there.");
                }
            }

            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:C:\\Users\\김지온\\Desktop\\프로그래밍\\qwe.sqlite";

            con = DriverManager.getConnection(url);

            Statement stmt = con.createStatement();

            stmt.execute("create table qwe(no int, name varchar(50))");

            stmt.execute("insert into qwe values(0, 'qqqq')");
            stmt.execute("insert into qwe values(1, 'wwww')");
            stmt.execute("insert into qwe values(2, 'eeee')");

            ResultSet rs = stmt.executeQuery("select no, name from qwe");
            while(rs.next()) {
                int no = rs.getInt(1);
                String name = rs.getString(2);
                System.out.println(no+","+name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(con != null) {
                try {
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}